
var ex2 = (function () {
    // private members: an array of courses and a string of the HTML to display
    let childrenList = [];
    let numChild = 0;
    let result = "";


    // this is the object we want to return (what we want public under our namespace)
    // we're going to add methods and a class formDetail definition
    var publicData = {};

    //set num of child outside the ex scope
    publicData.setNumChildren = function (num){
        numChild = num;
    };

    //show the error list on the screen and add erorr list html tage of al errors
    publicData.activateErorrList = function (){
        document.getElementById("errors-div").style.display = "block";
        document.getElementById("errors-list").innerHTML = result;
    };

    //build list with input children of the user
    publicData.buildChildrenList = function (numChildren){
        let k = 1, max = parseInt(numChildren) + 1;
        let childList = [];
        while (k < max) {
            childList.push(document.getElementById("child-input" + k).value);
            k++;
        }
        childList.sort();
        return childList;
    };

    //add child label and input using crate element and append
    function addChild(value){
        let newChild = document.createElement('tr');
        document.getElementById("children-names").appendChild(newChild);
        newChild = document.createElement('td');
        newChild.textContent = value;
        document.getElementById("children-names").appendChild(newChild);
    };

    /* 1) Show children table 2) create array with all user inputs
      3) each one of the values in the array create tr and td and add to the table*/
    function manageChildren(numChildren){
        if (numChildren > 0) {
            document.getElementById("data-children").style.display = "block";
            childrenList = publicData.buildChildrenList(numChildren);
            childrenList.forEach(addChild);
        }
    };

    /*arrage show screen and insert all user input values to the data table
        and call function to take care of the children show*/
    publicData.buildData = function (detail){
        document.getElementById("errors-div").style.display = "none";
        document.getElementById("form-information").style.display = "none";
        document.getElementById("children").style.display = "none";
        document.getElementById("data-Table").style.display = "block";
        document.getElementById("firstName").innerHTML = "FirstName: " + detail.firstName;
        document.getElementById("lastName").innerHTML = "LastName: " + detail.lastName;
        document.getElementById("birthYear").innerHTML = "Birth year: " + detail.birthYear;
        document.getElementById("immigrationYear").innerHTML = "Immigration year: "
            + detail.immigrationYear;
        document.getElementById("send-button").style.display = "none";
        document.getElementById("done-button").style.display = "block";
        manageChildren(detail.numChildren);
    };

    //check if children num is number between 0-10
    publicData.validChildrenNum = function(num){
// If x is Not a Number or less than one or greater than 10
        if (isNaN(num)) {
            result += "<li>num of children isnt number </li>";
            return false;
        }
        else if (num < 0 || num > 10) {
            //publicData.setNumChildren(0);//
            result += "<li>number is not valid between 0-10 </li>";
            return false;
        }
        return true;
    };

    publicData.addLabel = function(value){
        let newLabel = document.createElement('label');
        newLabel.id = "child-label" + value;
        newLabel.textContent = "Child Name " + value;
        document.getElementById("children").appendChild(newLabel);
    };

    publicData.addInput = function(value){
        let newInput = document.createElement('input');
        newInput.id = "child-input" + value;
        document.getElementById("children").appendChild(newInput);
    };

    publicData.addLine = function(value){
        let newLine = document.createElement('br');
        newLine.id = "br" + value;
        document.getElementById("children").appendChild(newLine);
    };

    publicData.addLabelInput = function(value){
        publicData.addLine(value)
        publicData.addLabel(value);
        publicData.addInput(value);
    };


    publicData.addChildren = function(newNumChild, numChildValid) {
        if(parseInt(newNumChild) > numChild && numChildValid ) {
            for (let i = numChild + 1; i < parseInt(newNumChild) + 1; i++) {
                publicData.addLabelInput(i);
            }
        }
    };

    //compare how many child children already have and if the new user input for children is lower delete the
    // oldChildren - newChildren
    publicData.removeChildren = function(newNumChild) {
        if (parseInt(newNumChild) < numChild) {
            for (let j = parseInt(newNumChild) + 1; j < numChild + 1; j++) {
                document.getElementById("children").removeChild(
                    document.getElementById("child-label" + j));
                document.getElementById("children").removeChild(
                    document.getElementById("child-input" + j));
                document.getElementById("children").removeChild(
                    document.getElementById("br" + j));
            }
        }
    };

    //get the current year
    function getYear(){
        let date = new Date();
        let cureYear = date.getFullYear();
        return cureYear;
    };


    /*check if year are valid:
     birthYear - check its bigger than 1900 and lower than current year
     * */
    function validYears(name, year,compareYear){
        if (isNaN(year)) {
            result += "<li>" + name + " isn't a number </li>";
            return false;
        }
        else if (year < compareYear)  {
            result += '<li>' + year +' is lower than' + compareYear + '</li>';
            return false;
        }
        else if(year > getYear()){
             result += '<li>' + year +' is bigger than' + getYear() + '</li>';
             return false;
        }
        return true;
    };

    //check all children user input isnt empty
    function validateFillChildren(){
        let n =1, maxC = parseInt(numChild) +1;
        let isValidate = true;
        while (n < maxC)
        {
            if (document.getElementById("child-input" + n).value == ""){
                result += "<li>Child name " + n +" is missing</li>";
                isValidate =  false;
            }
            n++;
        }
        return isValidate;
    };

    //valid if the is have the same children name twice
    function validSameNameChildren(numChildren){
        let arr = publicData.buildChildrenList(numChildren);
        for ( let i = 1; i < arr.length; i++ ){
            if(arr[i-1] === arr[i]) {
                result += "<li>Child name should be different</li>";
                return false;
            }
        }
        return true;
    };

    //check user input value isn't empty for giving name input
    function validNameEmpty(kindName,name){
        if (name.length == 0) {
            result += "<li>" + kindName + " is missing</li>";
            return false;
            }
        return true;
    };

    /*we build a new class formDetails responsible the form information:
     - holding all user values
     - check user values is valid and if not upload erorr list

     */
    publicData.formDetails = (function () {
        //class member
        let _isValid = true;
        //constructor
        var Details = function(firstName ="", lastName="", birthYear="",
                               immigrationYear="", numChildren=0) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.birthYear = birthYear;
            this.immigrationYear = immigrationYear;
            this.numChildren = numChildren;
            result = "";
            this.setValid();
        }
        //set valid
        Details.prototype.setValid = function (){
            _isValid = this.checkValidates();
        };
        //get valid
        Details.prototype.getValid = function (){
            return _isValid;
        };

        //check validation and insert results all the errors
        Details.prototype.checkValidates = function (){
            _isValid = true;

            _isValid = (validNameEmpty("First name", this.firstName) && _isValid);

            _isValid = (validNameEmpty("Last name", this.lastName) && _isValid);

            _isValid = (validNameEmpty("birth year", this.birthYear) &&
                validYears("birth year",this.birthYear, 1900) && _isValid);

            _isValid = ((validNameEmpty("immigration year", this.immigrationYear) &&
                validYears("immigration year",this.immigrationYear, this.birthYear)) && _isValid);

            _isValid = (publicData.validChildrenNum(this.numChildren) && validateFillChildren()
                && validSameNameChildren(this.numChildren) && _isValid);
            return _isValid;
        };
        return Details;
    })();
    // we return the object containing the 'public' functions
    return publicData;
})();  // end of definition and building of our namespace ex2

// PREPARE THE BUTTONS LISTENERS for testing
// wait for the DOM before reaching elements
window.addEventListener('DOMContentLoaded', (event) => {
    let val = true;
    //listener for send button
    document.getElementById("send-button").addEventListener('click', function () {

        let formdetails1 = new ex2.formDetails(document.getElementById("first-name").value,
            document.getElementById("last-name").value,
            document.getElementById("birth-year").value,
            document.getElementById("immigration-year").value,
            document.getElementById("children-num-box").value)
        val = formdetails1.getValid();
        if (val == true)
            ex2.buildData(formdetails1);
        else
            ex2.activateErorrList();
    });

    //listener for done button and refresh all back to the start
    document.getElementById("done-button").addEventListener('click', function (){
        document.getElementById("data-Table").style.display = "none";

        document.getElementById("send-button").style.display = "block";

        document.getElementById("done-button").style.display = "none";

        document.getElementById("form-information").style.display = "block";
        document.getElementById("children").style.display = "block";

        document.getElementById("data-children").style.display = "none";

        document.getElementById("children-names").innerText = "";

        location.reload();
    });


    //listener for change the number of children the user insert and create input as much as the user ask
    document.getElementById("children-num-box").addEventListener('change', function (){
        let newNumChild = document.getElementById("children-num-box").value;
        val = ex2.validChildrenNum(newNumChild);
        if(val) {
            ex2.addChildren(newNumChild, val);
            ex2.removeChildren(newNumChild);
            ex2.setNumChildren(parseInt(document.getElementById("children-num-box").value));
        }
        else {
            ex2.removeChildren(0);
            ex2.setNumChildren(0);//
        }
    });
});

