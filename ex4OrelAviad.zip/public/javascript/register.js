var valid = (function () {
    // private members: an array of courses and a string of the HTML to display

    let result = "";
    let  publicData = {};

    //activate errors list
    publicData.activateErorrList = function (){
        document.getElementById("errors-div").style.display = "block";
        document.getElementById("errors-list").innerHTML = result;
        result =""
    };

        //check user input value isn't empty for giving name input
    publicData.validNameEmpty = function(kindName, name){
            if (name.length == 0) {
                result += "<li>" + kindName + " is missing</li>";
                return false;
            }
            return true;
        };

        //check there isnt already same name locatin on dropdown
    publicData.validNameStr = function (kindName,name){
            if (/[^a-zA-Z+" "]/.test(name)){
                result += '<li>'+kindName+ ': '+ name + ' contains digits or signs or not only english letters</li>';
                return false;
            }
            return true;
        };
        //check validation and insert results all the errors
    publicData.checkValidates = function (firstName,lastName){
            let _isValid = true;
            _isValid = (publicData.validNameEmpty("First Name", firstName) && _isValid);
            _isValid = (publicData.validNameEmpty("Last Name", lastName)&& _isValid);
            _isValid = (publicData.validNameStr("First Name",firstName) &&
                publicData.validNameStr("Last Name",lastName) &&_isValid);
            return _isValid;
        };
    return publicData;
})();  // end of definition and building of our namespace ex3

window.addEventListener('DOMContentLoaded', (event) => {
    //listener for send button
    document.getElementById("form").addEventListener('submit', function (event) {
        let registerData = document.querySelectorAll("input")
        if(!valid.checkValidates(registerData[1].value, registerData[2].value)){
            event.preventDefault();
            valid.activateErorrList();
        }
    });
});
