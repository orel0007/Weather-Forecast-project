
var ex4 = (function () {
    // private members: an array of courses and a string of the HTML to display
    let result = "";
    let  publicData = {};
    let weekArr= ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    let d = new Date
    let curDay = d.getDay();

    //open dialog error
    publicData.openDialog = function() {
        // exceptionally we are using jQuery....
        $('#exampleModal').modal('show');
    }

    //activate errors list
    publicData.activateErorrList = function (){
        document.getElementById("errors-div").style.display = "block";
        document.getElementById("errors-list").innerHTML = result;
        result =""
    };

        //check user input value isn't empty for giving name input
    publicData.validNameEmpty = function(kindName, name){
            if (name.length == 0 || name === "") {
                result += "<li>" + kindName + " is missing</li>";
                return false;
            }
            return true;
        };

        //check the number is between -limit to limit
    publicData.validLimit = function(name, num,limit){
            if (isNaN(num)) {
                result += "<li>" + name +" error: " + num + " isn't a number </li>";
                return false;
            }
            else if (num < -limit)  {
                result += '<li>' + name +" error: " + num +' is lower than limit ' + -limit + '</li>';
                return false;
            }
            else if(num > limit){
                result += '<li>' + name +" error: " + num +' is bigger than limit ' + limit + '</li>';
                return false;
            }
            return true;
        };

        //check if number is decimal or isn't
    publicData.validdecimal = function(name, num){
            if (num % 1 == 0) {
                if (isNaN(num)) {
                    result += "<li>" + name + " error: " + num + " isn't a number </li>";
                    return false;
                }
            }
            return true;
        };

        //check there isnt already same name locatin on dropdown
    publicData.validNameStr = function (name){
            if (/[^a-zA-Z+" "]/.test(name)){
                result += '<li>Location name: ' + name + ' contains digits or signs and not only letters</li>';
                return false;
            }
            return true;
        };

        //check there isn't already same name location on dropdown
    publicData.validNameOption = function (name){
            let option =  document.querySelector("#locations");
            let num = option.childElementCount;
            for (let i = 0; i < num; i++)
            {
                if (option[i].value == name){
                    result += '<li>Location name: ' + name + ' is already exists</li>';
                    return false;
                }
            }
            return true;
        };

        //check validation and insert results all the errors
    publicData.checkValidates = function (name,lat,long){
        let _isValid= true;
            _isValid = (this.validNameEmpty("Location Name", name) && _isValid);

            _isValid = (this.validNameEmpty("Latitude", lat)&&
                this.validLimit("Latitude", lat,90) &&
                this.validdecimal("Latitude", lat) && _isValid);

            _isValid = (this.validNameEmpty("Longitude", long) &&
                this.validLimit("Longitude", long,180)&&
                this.validdecimal("Longitude", long) && _isValid);
            _isValid = (this.validNameOption(name) && this.validNameStr(name)
                &&_isValid);
            return _isValid;
        };

    //using ajax for get information from server, if success show it to user,otherwise raise a error modal
    publicData.getData= function(lon,lat){
        let load  = document.getElementById('load-img');
        load.style.display = "block"
        document.getElementById("buttons").style.display="none";
        fetch('http://www.7timer.info/bin/api.pl?lon='+lon+'lon&lat='+lat +'&product=civillight&output=json')
            .then(
                function (response) {
                    //handle the error:cant connect to the server
                    if (response.status !== 200) {
                        ex4.openDialog();
                        return;
                    }
                    // Examine the response and generate the HTML
                    response.json().then(function (data) {
                        publicData.insertDayWeather(data);
                        publicData.uploadImage(lon,lat);
                        load.style.display = "none";
                        document.getElementById("week-weather").style.display="block";
                        document.getElementById("buttons").style.display="block";
                    });
                }
            )
            .catch(function (err) {
               //ex4.openDialog();
            });
    };

    //return the string of the current day
    publicData.getNextDay = function()
    {
        if (curDay < 6) {
            curDay += 1
            return weekArr[curDay-1];
        }
        else {
            curDay -= 5;
            return weekArr[curDay-1];
        }
    }

    function loadImage(url){
        return new Promise(function(resolve, reject) {
            var img = new Image();
            img.src = url;
            img.onload = function() { resolve(img) }
            img.onerror = function(e) { reject(e) }
        });
    }

    //handle jason information from the api and insert it to the cars showing the weather for next week
    publicData.insertDayWeather = function(data)
    {
        let card = document.querySelectorAll(".card-group .card-text");
        for (let day = 0; day < 7; day++) {
            card[day].innerHTML  =publicData.getNextDay()+"<br>" ;
            card[day].innerHTML +="Temperature:<br>" + data.dataseries[day].temp2m.min+
                "<span>&#176;</span>" +" - "+ data.dataseries[day].temp2m.max
                +"<span>&#176;</span>" + "<br>";
            //if wind bigger than 1 add it
            if (data.dataseries[day].wind10m_max > 1)
                card[day].innerHTML+="wind: " + data.dataseries[day].wind10m_max+"<br>";
            //add weather name
            card[day].innerHTML+=data.dataseries[day].weather+ ": <br> ";
            //add weather icon only if succes to load it;
            let url= "/images/"+data.dataseries[day].weather+".png";
            var imgPromise = loadImage(url);
            imgPromise.then(function (img){
                //img.classList.add("col-12 col-md-6 col-sm-12");
                card[day].appendChild(img);
                card[day].querySelector('p img').classList = ("col-12 col-md-12 col-sm-12");
            }).catch(function(e){
                console.log("picture with "+ url +" wasnt able to load so keep it with weather name+" +
                    "and without icon")
                let newImg = document.createElement('img');
                newImg.src ="https://purepng.com/public/uploads/large/purepng.com-" +
                    "weather-iconsymbolsiconsapple-iosiosios-8-iconsios-8-721522596142qx4ep.png";
                newImg.classList = ("col-12 col-md-12 col-sm-12");
                card[day].appendChild(newImg);
            });
        }
    }

    //using ajax to load the weather and upload defult image if cant success
    publicData.uploadImage = function(lon,lat){
        let weatherImg = document.getElementById("weather-img");
        let errorMsg = document.getElementById("error-img");
        let newImage = "http://www.7timer.info/bin/astro.php? lon="+lon+"&lat="+lat+
            "&ac=0&lang=en&unit=metric&output=internal&tzshift=0"
        var imgPromise = loadImage(newImage);
        imgPromise.then(function (img){
            errorMsg.innerHTML="";
            weatherImg.src = newImage;
        }).catch(function(e){
            errorMsg.innerText= "Error get picture from server, show deafult photo of jerusalem";
            weatherImg.src = "img/jerusalem-weather.png";
        });
    }


    //reset all inputs after enter location
    publicData.resetInputs = function(){
        let inputs =  document.querySelectorAll("input");
        let num = inputs.length;
        for (let i = 0; i < num; i++)
            inputs[i].value="";
    };

    // we return the object containing the 'public' functions
    return publicData;
})();  // end of definition and building of our namespace ex2

//dropDown functions
var dropDown = (function (location) {
    let publicData ={};
    //add new Location to dropDown
    publicData.addNewLocation = function (name, lat, lon){
        publicData.addOption(name, lat, lon);
    }

    //add new option to dropDown
    publicData.addOption = function(name, lat, lon){
        let newChild = document.createElement('option');
        newChild.textContent = name;
        newChild.setAttribute("data-latitude", lat)
        newChild.setAttribute("data-longitude", lon)
        document.getElementById("locations").appendChild(newChild);

    }
    return publicData;
})();  // end of definition and building of our namespace ex2

var server = (function (location) {
    let publicData = {};
    //create new location by api add it to user table location list
    publicData.addLocation =function(){
        document.getElementById("errors-div").style.display = "none";
        let option =  document.querySelectorAll("input");
        let nameLocation = option[0].value.trim();
        let lat = option[1].value.trim();
        let long = option[2].value.trim();
        const data = {name: nameLocation, latitude: lat, longitude:long};
        fetch('/api/addLocation', {
            method: 'post',
            headers: {'Content-Type' :'application/json'},
            body:JSON.stringify(data)}
            )
            .then(
                function (response) {
                    //handle the error:cant connect to the server
                    if (response.status !== 200) {
                        console.log("error response status ")
                        ex4.openDialog();
                        return;
                    }
                    dropDown.addNewLocation(nameLocation, lat, long);
                    ex4.resetInputs();
                }
            )
            .catch(function (err) {
                console.log("error send post to add location")
                ex4.openDialog();
            });
    }

    //api- get all locaions user list by his email
    publicData.getLocations =function(){
        fetch('/api/getLocations', {method: 'get'})
            .then(
                function (response) {
                    //handle the error:cant connect to the server
                    if (response.status !== 200) {
                        return;
                    }
                    response.json().then(function (data) {
                        let i;
                        for (i in data)
                            dropDown.addNewLocation(data[i].name, data[i].latitude, data[i].longitude);
                    });
                }
            )
            .catch(function (err) {
                console.log("error send post to GET location list")
                ex4.openDialog();
            });
    }

    //delete all locations from the user data base table
    publicData.deleteAllLocations = function(){
        fetch('/api/deleteAllLocation', {method: 'delete'})
            .then(function (response) {
                    //handle the error:cant connect to the server
                    if (response.status !== 200) {
                        ex4.openDialog();
                        return;
                    }
                    buttons.deleteLocations();
                }
            ).catch(function (err) {
                console.log("error delete all locations")
                ex4.openDialog();
            });
    }

    //delete location usuing api
    publicData.deleteLocation = function(){
        let option =  document.querySelector("#locations");
        let index  = option.selectedIndex;
        let optionIndex = option.getElementsByTagName('option')[index];
        fetch('/api/deleteLocation/'+optionIndex.value, {method: 'delete'})
            .then(function (response) {
                    //handle the error:cant connect to the server
                    if (response.status !== 200) {
                        ex4.openDialog();
                        return;
                    }
                    buttons.deleteLocation(option,index);
            }).catch(function (err) {
                console.log("error delete location: " + optionIndex.value);
                ex4.openDialog();
         });

    }
    return publicData;
})();


//buttons functions
var buttons = (function (location,event) {
    let publicData = {};
    //Check valid data
    publicData.sendValid= function(){
        let formData = document.querySelectorAll("input")
        let valid =  ex4.checkValidates(formData[0].value,formData[1].value,formData[2].value);
        return valid;
    }

    //display button get information from api server and show it
    publicData.displayButton =function(){
        document.getElementById("errors-div").style.display ="none";
        document.getElementById("week-weather").style.display ="none";
        let option =  document.querySelector("#locations");
        let index  = option.selectedIndex;
        if (index!= 0) {
            let optionIndex = option.getElementsByTagName('option')[index];
            let lat = optionIndex.getAttribute("data-latitude");
            let long = optionIndex.getAttribute("data-longitude");
            ex4.getData(long, lat);
            let title = document.querySelector("#week-weather h2");
            title.innerHTML +=  optionIndex.value;
        }
    }

    //delete all locations from dropDown using deleteLocation func
    publicData.deleteLocations = function(){
        let option =  document.querySelector("#locations");
        let num = option.length;
        for (let step = 1; step < num + 1; step++) {
            publicData.deleteLocation(option,1);
        }
    }

    //delete location from dropDown
    publicData.deleteLocation = function(doc,index) {
        if (index != 0) {
            doc.removeChild(doc.getElementsByTagName('option')[index]);
            document.getElementById("week-weather").style.display = "none";
        }
    }
    //return publicData
    return publicData;
})();

// PREPARE THE BUTTONS LISTENERS for testing
// wait for the DOM before reaching elements
window.addEventListener('DOMContentLoaded', (event) => {
    //when load html for the first time get user location list and update dropdown
    server.getLocations();
    //listener for send button, if insert valid add this location to data base using api
    document.getElementById("send-button").addEventListener('click', function (event) {
        if(!buttons.sendValid()) {
            ex4.activateErorrList();
        }
        else {
            server.addLocation();
        }
    });
    //listener for display button, usuing api update the weather for next week
    document.getElementById("display-button").addEventListener('click', function () {
        buttons.displayButton();
    });
    //listener for delete button
    document.getElementById("delete-button").addEventListener('click', function () {
        server.deleteLocation();
    });
    //listener for reset button, delete all user locations in the data base
    document.getElementById("reset-button").addEventListener('click', function () {
        server.deleteAllLocations();
    });
});

