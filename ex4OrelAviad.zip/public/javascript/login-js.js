var valid = (function () {
    // private members: an array of courses and a string of the HTML to display
    let result = "";
    let  publicData = {};
    //activate errors list
    publicData.activateErorrList = function (){
        document.getElementById("errors-div").style.display = "block";
        document.getElementById("errors-list").innerHTML = result;
        result =""
    };

    //check user input value isn't empty for giving name input
    publicData.validNameEmpty = function(kindName, name){
        if (name.length == 0) {
            result += "<li>" + kindName + " is missing</li>";
            return false;
        }
        return true;
    };
    //check user input value isn't empty for giving name input
    publicData.checkValidates = function(email, password){
        let _is_valid = publicData.validNameEmpty("Email", email);
        _is_valid = publicData.validNameEmpty("Password", password);
        return _is_valid;
    };
    return publicData;
})();  // end of definition and building of our namespace ex3

window.addEventListener('DOMContentLoaded', (event) => {
    //listener for send button
    document.getElementById("form").addEventListener('submit', function (event) {
        let userData= document.querySelectorAll("input")
        if(!valid.checkValidates(userData[0].value, userData[1].value)){
            event.preventDefault();
            valid.activateErorrList();
        }
    });
});
