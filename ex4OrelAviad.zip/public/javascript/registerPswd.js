var valid = (function () {
    // private members: an array of courses and a string of the HTML to display
    let result = "";
    let  publicData = {};
    //activate errors list
    publicData.activateErorrList = function (){
        document.getElementById("errors-div").style.display = "block";
        document.getElementById("errors-list").innerHTML = result;
        result =""
    };

    //check user input value isn't empty for giving name input
    publicData.validLength = function(name){
        if (name.length < 8) {
            result += "<li> Password length is less than 8 </li>";
            return false;
        }
        return true;
    };

    publicData.samePassword = function(password1, password2){
        if (password1 !== password2) {
            result += "<li> Password1 and password 2 isn't the same </li>";
            return false;
        }
        return true;
    };

    //check validation and insert results all the errors
    publicData.checkValidates = function (password1, password2){
        let _isValid = publicData.validLength(password1) && (publicData.samePassword(password1,password2));
        return _isValid
    };
    return publicData;
})();  // end of definition and building of our namespace ex3

window.addEventListener('DOMContentLoaded', (event) => {
    //listener for send button
    document.getElementById("form").addEventListener('submit', function (event) {
        let userPassword= document.querySelectorAll("input")
        if(!valid.checkValidates(userPassword[0].value, userPassword[1].value)){
            event.preventDefault();
            valid.activateErorrList();
        }
    });
});
