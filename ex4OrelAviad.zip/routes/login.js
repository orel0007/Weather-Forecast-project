var express = require('express');
var router = express.Router();
var Cookies = require('cookies')
var bodyParser = require('body-parser')

const db= require('../models')
var cookies;

//--------------login----------------------
router.post('/login', function(req, res, next) {
    var isTime = req.cookies.timer;
    if (!isTime)
        res.render('register', {title: 'Its had been passes more than a minute on password page, register again'});
    else {
        return db.Users.findOne({
            where: {email: req.session.email}
        }).then(function(user){
            if(!user){
                let email = req.session.email;
                let firstName = req.session.firstName;
                let lastName = req.session.lastName;
                let password = req.body.psw;
                db.Users.create({ email, firstName, lastName, password })
                    .then(function (users) {
                        res.render('loginPage', {title: 'you are registered' });
                        res.status(200).send(users);
                    })
                    .catch((err) => {
                        console.log('***There was an error creating a new user')
                        return res.status(400).send(err)
                    })
            }
            else{
                res.render('register', { title: 'the email you insert already in use, choose diff email' });
            }

        })
            .catch((err) => {
                console.log('***There was an error approach the server')
                return res.status(400).send(err)
            })
    }
});

router.get('/login', function(req, res, next) {
    req.session.isLogin = false;
    res.render('loginPage', { title: 'Insert your email and password'});
});

module.exports = router;
