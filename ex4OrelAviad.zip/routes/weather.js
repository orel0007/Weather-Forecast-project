var express = require('express');
var router = express.Router();
var Cookies = require('cookies')
var bodyParser = require('body-parser')

const db= require('../models')

//--------------weather----------------------
router.post('/weather', function(req, res, next) {
    return db.Users.findOne({
        where: {email: req.body.email}
    }).then(function(email){
        if (!email)
            res.render('loginPage', {title: 'Email is not registered'});
        else{
            return db.Users.findOne({
                where: {
                    email: req.body.email,
                    password: req.body.password}
            }).then(function(password){
                if (!password)
                    res.render('loginPage', {title: 'Password isn\'t match this email'});
                else {
                    req.session.isLogin = true;
                    req.session.email = req.body.email;
                    res.render('weather', { userName: req.body.email });
                }
            })
                .catch((err) => {
                    console.log('***There was an error search in the database')
                    return res.status(400).send(err)
                })
        }

    })
        .catch((err) => {
            console.log('***There was an error search in the database')
            return res.status(400).send(err)
        })

});

router.get('/weather', function(req, res, next) {
    if (req.session.isLogin) {
        res.render('weather', { userName: req.session.email });
    }
    else
        res.render('register', { title: 'you should register or login before you can go inside weather' });
});

module.exports = router;