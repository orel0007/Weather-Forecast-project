var express = require('express');
var router = express.Router();
const db= require('../models')

router.use(isLogin);

function isLogin(req,res,next)
{
    if (!req.session.isLogin)
        res.render('login', { title: 'You should login again' });
    next()
}

//--------------api----------------------
router.get('/getLocations', function(req, res, next) {
        return db.Locations.findAll({
            where: {
                email: req.session.email,
            }
        }).then(function (users) {
            res.status(200).send(users);
        })
            .catch((err) => {
                console.log('***There was an error send all user locations')
                return res.status(400).send(err)
            })
});


//--------------api----------------------
router.post('/addLocation',function(req, res, next) {
        let email = req.session.email;
        let name = req.body.name;
        let latitude = req.body.latitude;
        let longitude = req.body.longitude;
        return db.Locations.create({email, name, latitude, longitude})
            .then((user) => res.status(200).send("sucess"))
            .catch((err) => {
                console.log('***There was an error creating a new location')
                return res.status(400).send(err)
            })
});

// Deleting a resource
router.delete('/deleteAllLocation', (req, res) => {
    // If resource not found, return 404, otherwise delete it
        return db.Locations.destroy({
            where:{email: req.session.email}
        }).then((user) => res.status(200).send("sucess"))
            .catch((err) => {
                console.log('***There was an error delete all user locations')
                return res.status(400).send(err)
            })
});


// Deleting a resource
router.delete('/deleteLocation/:name', (req, res) => {
    // If resource not found, return 404, otherwise delete it
    let cityName = req.params.name;
    return db.Locations.destroy({
        where:{email: req.session.email, name:cityName}
    }).then(() => res.status(200).send("sucess"))
        .catch((err) => {
            console.log('***There was an error delete location: ' + req.params.name)
            return res.status(400).send(err)
        })

});

module.exports = router;