var express = require('express');
var router = express.Router();
var Cookies = require('cookies')
var bodyParser = require('body-parser')
const db= require('../models')

var cookies;


/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('register', { title: '' });
});

router.get('/register', function(req, res, next) {
    res.render('register', { title: '' });
});

router.post('/register/password', function(req, res, next) {
    req.session.email = req.body.email;
    req.session.firstName = req.body.fname;
    req.session.lastName = req.body.lname;
    //check if already exists
    db.Users.findOne({
            where: {email: req.body.email}
        }).then(function(email){
            if (!email){
                res.cookie('timer', 'true', {maxAge: 60 * 1000})
                res.render('registerPassword', { title: '' });
            }
            else
                res.render('register', { title: 'Email already in use, choose diff email' });
    })
        .catch((err) => {
            console.log('***Error deleting contact', JSON.stringify(err))
            res.status(400).send(err)
        })
});

router.get('/register/password', function(req, res, next) {
    res.render('register', { title: '' });
});

module.exports = router;