
var ex3 = (function () {
    // private members: an array of courses and a string of the HTML to display

    let result = "";
    let  publicData = {};
    let weekArr= ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    let d = new Date
    let curDay = d.getDay();

    //open dialog error
    publicData.openDialog = function() {
        // exceptionally we are using jQuery....
        $('#exampleModal').modal('show');
    }

    //activate errors list
    publicData.activateErorrList = function (){
        document.getElementById("errors-div").style.display = "block";
        document.getElementById("errors-list").innerHTML = result;
        result =""
    };
    //check all validate for enter a new location
    publicData.Validity = (function () {
        //class member
        let _isValid = true;
        //constructor
        var locationDetails = function(locationName ="", latitude="", longitude="") {
            this.locationName = locationName;
            this.latitude = latitude;
            this.longitude = longitude;
            this.setValid();
        }


        //check user input value isn't empty for giving name input
        locationDetails.prototype.validNameEmpty = function(kindName, name){
            if (name.length == 0) {
                result += "<li>" + kindName + " is missing</li>";
                return false;
            }
            return true;
        };

        //check the number is between -limit to limit
        locationDetails.prototype.validLimit = function(name, num,limit){
            if (isNaN(num)) {
                result += "<li>" + name +" error: " + num + " isn't a number </li>";
                return false;
            }
            else if (num < -limit)  {
                result += '<li>' + name +" error: " + num +' is lower than limit ' + -limit + '</li>';
                return false;
            }
            else if(num > limit){
                result += '<li>' + name +" error: " + num +' is bigger than limit ' + limit + '</li>';
                return false;
            }
            return true;
        };

        //check if number is decimal or isn't
        locationDetails.prototype.validdecimal = function(name, num){
            if (num % 1 == 0) {
                if (isNaN(num)) {
                    result += "<li>" + name + " error: " + num + " isn't a number </li>";
                    return false;
                }
            }
            return true;
        };

        //set valid
        locationDetails.prototype.setValid = function (){
            _isValid = this.checkValidates();
        };
        //get valid
        locationDetails.prototype.getValid = function (){
            return _isValid;
        };

        //check there isnt already same name locatin on dropdown
        locationDetails.prototype.validNameStr = function (name){
            if (/[^a-zA-Z+" "]/.test(name)){
                result += '<li>Location name: ' + name + ' contains digits or signs and not only letters</li>';
                return false;
            }
            return true;
        };

        //check there isn't already same name location on dropdown
        locationDetails.prototype.validNameOption = function (name){
            let option =  document.querySelector("#locations");
            let num = option.childElementCount;
            for (let i = 0; i < num; i++)
            {
                if (option[i].value == name){
                    result += '<li>Location name: ' + name + ' is already exists</li>';
                    return false;
                }
            }
            return true;
        };

        //check validation and insert results all the errors
        locationDetails.prototype.checkValidates = function (){
            _isValid = true;

            _isValid = (this.validNameEmpty("Location Name", this.locationName) && _isValid);

            _isValid = (this.validNameEmpty("Latitude", this.latitude)&&
                this.validLimit("Latitude", this.latitude,90) &&
                this.validdecimal("Latitude", this.latitude) && _isValid);

            _isValid = (this.validNameEmpty("Longitude", this.longitude) &&
                this.validLimit("Longitude", this.longitude,180)&&
                this.validdecimal("Longitude", this.longitude) && _isValid);
            _isValid = (this.validNameOption(this.locationName) && this.validNameStr(this.locationName)
                &&_isValid);

            return _isValid;
        };
        return locationDetails;
    })();

    //using ajax for get information from server, if success show it to user,otherwise raise a error modal
    publicData.getData= function(lon,lat){
        let load  = document.getElementById('load-img');
        load.style.display = "block"
        document.getElementById("buttons").style.display="none";
        fetch('http://www.7timer.info/bin/api.pl?lon='+lon+'lon&lat='+lat +'&product=civillight&output=json')
            .then(
                function (response) {
                    //handle the error:cant connect to the server
                    if (response.status !== 200) {
                        ex3.openDialog();
                        return;
                    }
                    // Examine the response and generate the HTML
                    response.json().then(function (data) {
                        publicData.insertDayWeather(data);
                        publicData.uploadImage(lon,lat);
                        load.style.display = "none";
                        document.getElementById("week-weather").style.display="block";
                        document.getElementById("buttons").style.display="block";
                    });
                }
            )
            .catch(function (err) {
                ex3.openDialog();
            });
    };

    //return the string of the current day
    publicData.getNextDay = function()
    {
        if (curDay < 6) {
            curDay += 1
            return weekArr[curDay-1];
        }
        else {
            curDay -= 5;
            return weekArr[curDay-1];
        }
    }

    function loadImage(url){
        return new Promise(function(resolve, reject) {
            var img = new Image();
            img.src = url;
            img.onload = function() { resolve(img) }
            img.onerror = function(e) { reject(e) }
        });
    }

    //handle jason information from the api and insert it to the cars showing the weather for next week
    publicData.insertDayWeather = function(data)
    {
        let card = document.querySelectorAll(".card-group .card-text");
        for (let day = 0; day < 7; day++) {
            card[day].innerHTML  =publicData.getNextDay()+"<br>" ;
            card[day].innerHTML +="Temperature:<br>" + data.dataseries[day].temp2m.min+
                "<span>&#176;</span>" +" - "+ data.dataseries[day].temp2m.max
                +"<span>&#176;</span>" + "<br>";
            //if wind bigger than 1 add it
            if (data.dataseries[day].wind10m_max > 1)
                card[day].innerHTML+="wind: " + data.dataseries[day].wind10m_max+"<br>";
            //add weather name
            card[day].innerHTML+=data.dataseries[day].weather+ ": <br> ";
            //add weather icon only if succes to load it;
            let url= "img/"+data.dataseries[day].weather+".png";
            var imgPromise = loadImage(url);
            imgPromise.then(function (img){
                //img.classList.add("col-12 col-md-6 col-sm-12");
                card[day].appendChild(img);
                card[day].querySelector('p img').classList = ("col-12 col-md-12 col-sm-12");
            }).catch(function(e){
                console.log("picture with "+ url +" wasnt able to load so keep it with weather name+" +
                    "and without icon")
                let newImg = document.createElement('img');
                newImg.src ="https://purepng.com/public/uploads/large/purepng.com-" +
                    "weather-iconsymbolsiconsapple-iosiosios-8-iconsios-8-721522596142qx4ep.png";
                newImg.classList = ("col-12 col-md-12 col-sm-12");
                card[day].appendChild(newImg);
            });
        }
    }

    //using ajax to load the weather and upload defult image if cant success
    publicData.uploadImage = function(lon,lat){
        let weatherImg = document.getElementById("weather-img");
        let errorMsg = document.getElementById("error-img");
        let newImage = "http://www.7timer.info/bin/astro.php? lon="+lon+"&lat="+lat+
            "&ac=0&lang=en&unit=metric&output=internal&tzshift=0"
        var imgPromise = loadImage(newImage);
        imgPromise.then(function (img){
            errorMsg.innerHTML="";
            weatherImg.src = newImage;
        }).catch(function(e){
            errorMsg.innerText= "Error get picture from server, show deafult photo of jerusalem";
            weatherImg.src = "img/jerusalem-weather.png";
        });
    }

    //reset all inputs after enter location
    publicData.resetInputs = function(){
        let inputs =  document.querySelectorAll("input");
        let num = inputs.length;
        for (let i = 0; i < num; i++)
            inputs[i].value="";
    };
    // we return the object containing the 'public' functions
    return publicData;
})();  // end of definition and building of our namespace ex2

//dropDown functions
var dropDown = (function (location) {
    let publicData ={};
    publicData.addNewLocation = function (location){
        document.getElementById("errors-div").style.display = "none";
        publicData.addOption(location);
    }

    //add new locaion to dropDown
    publicData.addOption = function(location){
        let newChild = document.createElement('option');
        newChild.textContent = location.locationName;
        newChild.setAttribute("data-latitude", location.latitude)
        newChild.setAttribute("data-longitude", location.longitude)
        document.getElementById("locations").appendChild(newChild);
    }
    return publicData;
})();  // end of definition and building of our namespace ex2

//buttons functions
var buttons = (function (location) {
    let publicData = {};
    //create new location: check if validate add it to dropDown otherwise show the user the mistakes
    publicData.sendButton =function(){
        let formData = document.querySelectorAll("input")
        let location = new ex3.Validity(formData[0].value,
            formData[1].value,
            formData[2].value)
        let val = location.getValid();
        if (val == true){
            dropDown.addNewLocation(location);
            ex3.resetInputs();
        }
        else
            ex3.activateErorrList();
        document.getElementById("week-weather").style.display = "none";
    }

    //display button get information from api server and show it
    publicData.displayButton =function(){
        document.getElementById("errors-list").style.display ="none";
        document.getElementById("week-weather").style.display ="none";
        let option =  document.querySelector("#locations");
        let index  = option.selectedIndex;
        if (index!= 0) {
            let optionIndex = option.getElementsByTagName('option')[index];
            let lat = optionIndex.getAttribute("data-latitude");
            let long = optionIndex.getAttribute("data-longitude");
            ex3.getData(long, lat);
            let title = document.querySelector("#week-weather h2");
            title.innerHTML = title.getAttribute("data-title") + optionIndex.value;
        }
    }
    //delete location from dropDown
    publicData.deleteLocation = function(){
        let option =  document.querySelector("#locations");
        let i  = option.selectedIndex;
        if (i != 0)
            option.removeChild(option.getElementsByTagName('option')[i]);
        document.getElementById("week-weather").style.display = "none";
    }
    return publicData;
})();

// PREPARE THE BUTTONS LISTENERS for testing
// wait for the DOM before reaching elements
window.addEventListener('DOMContentLoaded', (event) => {
    //listener for send button
    document.getElementById("send-button").addEventListener('click', function () {
        buttons.sendButton();
    });
    //listener for display button
    document.getElementById("display-button").addEventListener('click', function () {
        buttons.displayButton();
    });
    //listener for delete button
    document.getElementById("delete-button").addEventListener('click', function () {
        buttons.deleteLocation();
    });
});

